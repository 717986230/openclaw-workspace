#!/usr/bin/env python3
"""
验证优化后的数据库功能是否正常
"""
import sqlite3
import sys

if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')

def test_database():
    """测试数据库功能"""
    db_path = 'memory/database/xiaozhi_memory.db'
    
    print("="*60)
    print("数据库功能验证测试")
    print("="*60)
    print(f"\n数据库: {db_path}\n")
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    tests_passed = 0
    tests_failed = 0
    
    # 测试1: 连接和基本查询
    print("测试1: 数据库连接和基本查询...")
    try:
        cursor.execute("SELECT COUNT(*) FROM memories")
        count = cursor.fetchone()[0]
        print(f"  [PASS] memories 表有 {count} 条记录")
        tests_passed += 1
    except Exception as e:
        print(f"  [FAIL] 查询失败: {e}")
        tests_failed += 1
    
    # 测试2: 全文搜索
    print("\n测试2: 全文搜索功能(FTS5)...")
    try:
        cursor.execute("SELECT COUNT(*) FROM memory_index")
        count = cursor.fetchone()[0]
        print(f"  [PASS] memory_index 表有 {count} 条记录")
        tests_passed += 1
    except Exception as e:
        print(f"  [FAIL] FTS5 查询失败: {e}")
        tests_failed += 1
    
    # 测试3: 关系查询
    print("\n测试3: 关系查询(knowledge_relations)...")
    try:
        cursor.execute("SELECT COUNT(*) FROM knowledge_relations")
        count = cursor.fetchone()[0]
        print(f"  [PASS] knowledge_relations 表有 {count} 条记录")
        tests_passed += 1
    except Exception as e:
        print(f"  [FAIL] 关系查询失败: {e}")
        tests_failed += 1
    
    # 测试4: 因果查询
    print("\n测试4: 因果关系查询...")
    try:
        cursor.execute("SELECT COUNT(*) FROM causal_relations")
        count = cursor.fetchone()[0]
        print(f"  [PASS] causal_relations 表有 {count} 条记录")
        tests_passed += 1
    except Exception as e:
        print(f"  [FAIL] 因果查询失败: {e}")
        tests_failed += 1
    
    # 测试5: 索引性能
    print("\n测试5: 索引性能...")
    try:
        cursor.execute("EXPLAIN QUERY PLAN SELECT * FROM memories WHERE type='learning'")
        plan = cursor.fetchall()
        if 'INDEX' in str(plan):
            print(f"  [PASS] 查询使用了索引")
        else:
            print(f"  [WARN] 查询可能未使用索引")
        tests_passed += 1
    except Exception as e:
        print(f"  [FAIL] 索引测试失败: {e}")
        tests_failed += 1
    
    # 测试6: 插入操作
    print("\n测试6: 插入操作...")
    try:
        cursor.execute("""
            INSERT INTO memories (type, title, content, category, importance, confidence)
            VALUES ('test', 'Test Entry', 'This is a test entry', 'test', 1, 0.5)
        """)
        conn.commit()
        cursor.execute("SELECT id FROM memories WHERE title='Test Entry'")
        test_id = cursor.fetchone()[0]
        print(f"  [PASS] 插入成功, ID: {test_id}")
        
        # 清理测试数据
        cursor.execute("DELETE FROM memories WHERE id=?", (test_id,))
        conn.commit()
        tests_passed += 1
    except Exception as e:
        print(f"  [FAIL] 插入失败: {e}")
        tests_failed += 1
    
    # 测试7: 连接查询
    print("\n测试7: 连接查询...")
    try:
        cursor.execute("""
            SELECT m.*, kr.relation_type
            FROM memories m
            LEFT JOIN knowledge_relations kr ON m.id = kr.source_memory_id
            LIMIT 5
        """)
        results = cursor.fetchall()
        print(f"  [PASS] 连接查询成功, 返回 {len(results)} 条记录")
        tests_passed += 1
    except Exception as e:
        print(f"  [FAIL] 连接查询失败: {e}")
        tests_failed += 1
    
    # 测试8: 排序和筛选
    print("\n测试8: 排序和筛选...")
    try:
        cursor.execute("""
            SELECT * FROM memories ORDER BY importance DESC, created_at DESC LIMIT 10
        """)
        results = cursor.fetchall()
        print(f"  [PASS] 排序查询成功, 返回 {len(results)} 条记录")
        tests_passed += 1
    except Exception as e:
        print(f"  [FAIL] 排序查询失败: {e}")
        tests_failed += 1
    
    # 测试9: 聚合查询
    print("\n测试9: 聚合查询...")
    try:
        cursor.execute("""
            SELECT type, COUNT(*), AVG(importance) FROM memories GROUP BY type
        """)
        results = cursor.fetchall()
        print(f"  [PASS] 聚合查询成功, 返回 {len(results)} 个分组")
        tests_passed += 1
    except Exception as e:
        print(f"  [FAIL] 聚合查询失败: {e}")
        tests_failed += 1
    
    # 测试10: 配置查询
    print("\n测试10: 配置表查询...")
    try:
        cursor.execute("SELECT * FROM config")
        results = cursor.fetchall()
        print(f"  [PASS] 配置查询成功, 返回 {len(results)} 条记录")
        tests_passed += 1
    except Exception as e:
        print(f"  [FAIL] 配置查询失败: {e}")
        tests_failed += 1
    
    conn.close()
    
    # 测试结果汇总
    print("\n" + "="*60)
    print("测试结果汇总")
    print("="*60)
    print(f"通过: {tests_passed}/{tests_passed + tests_failed}")
    print(f"失败: {tests_failed}/{tests_passed + tests_failed}")
    
    if tests_failed == 0:
        print("\n[OK] 所有测试通过! 数据库功能正常!")
    else:
        print(f"\n[WARN] {tests_failed} 个测试失败, 请检查")
    
    return tests_failed == 0

if __name__ == '__main__':
    success = test_database()
    sys.exit(0 if success else 1)
